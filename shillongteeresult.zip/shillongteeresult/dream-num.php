<?php include "header.php"; ?>

<div class="container-fluid vh-100">
    <?php include "nav-bar.php"; ?>

    <div class="row mt-3">
        <div class="col-md-12 py-3 heading-1">
            <h1 class="text-center">Dream Numbers</h1>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover text-center">
                    <thead>
                        <tr class="dream-bg">
                            <td>Dream</td>
                            <td>Numbers</td>
                            <td>House</td>
                            <td>Ending</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT * FROM dream_number WHERE time_period = 'day'";
                        $result = mysqli_query($con, $sql);

                        if (mysqli_num_rows($result) > 0) {
                            while ($fassoc = mysqli_fetch_assoc($result)) {
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($fassoc['dream']); ?></td>
                            <td><?php echo htmlspecialchars($fassoc['numbers']); ?></td>
                            <td><?php echo htmlspecialchars($fassoc['house']); ?></td>
                            <td><?php echo htmlspecialchars($fassoc['ending']); ?></td>
                        </tr>
                        <?php
                            }
                        } else {
                            echo "<tr><td colspan='4' class='text-danger fw-bold py-3'>No dream numbers available.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Navigation Buttons -->
    <div class="row d-none d-md-flex p-4 center mt-4">
        <a class="bg-image-1 bg-pos teer-box" href="common-num.php">
        </a>
        <a class="bg-image-2 bg-pos teer-box" href="index.php">
        </a>
        <a class="bg-image-6 bg-pos teer-box" href="prev-result.php">
        </a>
    </div>

    <div class="row center" style="margin-top: 2.5rem">
        <?php 
        $menuItems = [
            ['title' => 'COMMON NUMBER', 'link' => 'common-num.php', 'class' => 'bg-image-1'],
             ['title' => 'DEALS', 'link' => 'index.php', 'class' => 'bg-image-2'],
              ['title' => 'DREAM NUMBER', 'link' => 'dream-num.php', 'class' => 'bg-image-3'],
            
           ['title' => 'ANALYTICS', 'link' => 'index.php', 'class' => 'bg-image-4 disp-none'],
            ['title' => 'PREDICT TARGET', 'link' => 'index.php', 'class' => 'bg-image-5 disp-none'],
            ['title' => 'PREVIOUS RESULT', 'link' => 'prev-result.php', 'class' => 'bg-image-6'],
            ['title' => 'CALENDAR', 'link' => 'prev-result.php', 'class' => 'bg-image-7 disp-none'],
            ['title' => 'Reputed Counter', 'link' => 'index.php', 'class' => 'bg-image-8 disp-none'],
            ['title' => 'TARGET APP', 'link' => 'index.php', 'class' => 'bg-image-9 disp-none']
        ];
        
        foreach ($menuItems as $menuItem) {
            echo "<a class='bg-pos border teer-box {$menuItem['class']}' href='{$menuItem['link']}'></a>";
        }
        ?>
    </div>
</div>

<!-- Footer -->
<?php include "footer.php"; ?>
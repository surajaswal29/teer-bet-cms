<?php
if(!isset($_SESSION['uname'])){
    redirect("index.php");
}

?>
<div class="container-fluid bg-gully footer">
    <div class="row">
        <div class="col-md-12 text-center py-1 text-white">
            <span style="font-size:13px;">&copy; shillongteeresult.in | morning.shillongteeresult.in |
                night.shillongteeresult.in</span>
        </div>
    </div>
</div>

</body>

</html>